<?php
$title = "Weevil lookup - BWI";
include_once('header.php');
?>
<div class="container">
<div class="content">
<h1>amount</h1>
<?php
	include_once('utils.php');#
	makevalidsession();
	checkmulchandexp();

	var_dump($OUTPUTYOUBLACKNIGER);
?>
<h1>item giver 0day</h1>
<br />
<?php

	    function brainstrain2($score) {##game stuff
		$curl = curl_init("http://lb.binweevils.com/game/brain-submit?rndVar=0.35762571915984154");
		curl_setopt($curl, CURLOPT_POST, true);
		$levels = "0|2,1|0,3|6,4|0,5|4,7|2,8|2,9|3,10|0,11|2";
		$st = 122110;; // made it work ;p look into it more tho.
		$hash = o2_genhash($score.$levels.$st);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&levels=".$levels."&score=".$score."&st=".$st);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl); // works daily only.
		print 'received:'.$outputnigga;
		print '<h2>The mulch given was='.$score.' !</h2>'; #
		print $outputnigga;
		}

 foreach (range(130, 200) as $score) {
    brainstrain2($score);
 }


?>
</div>
</div>
<?php
include_once('footer.php');
?>