<?php
$title = "Weevil lookup - BWI";
include_once('header.php');
?>
<div class="container">
<div class="content">
<h1>amount</h1>
<?php
	include_once('utils.php');#
	makevalidsession();
	checkmulchandexp();

	var_dump($OUTPUTYOUBLACKNIGER);
?>
<h1>item giver 0day</h1>
<br />
<?php

	function item3($itemID) {
		$curl = curl_init("http://lb.binweevils.com/php2/nest/multiRewardItem.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$hash = o2_genhash($itemID.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "itemID=".$itemID."&timer=".$timer."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	}

foreach (range(54949491, 54949493) as $itemID) {
	item3($itemID);
 }


?>
</div>
</div>
<?php
include_once('footer.php');
?>