<?php
$title = "Weevil lookup - BWI";
include_once('header.php');
?>
<div class="container">
<div class="content">
<h1>amount</h1>
<?php
	include_once('utils.php');#
	makevalidsession();
	checkmulchandexp();

	var_dump($OUTPUTYOUBLACKNIGER);
?>
<h1>item giver 0day</h1>
<br />
<?php

	function itemhack($id) {
		$curl = curl_init("http://lb.binweevils.com/shop/buyitem");
		curl_setopt($curl, CURLOPT_POST, true);
		#$timer = timer_getandinc();
		$timer = timer_getandinc();
		$shop = "furniture";
		$itemColour = "-1";
		$hash = o2_genhash($id.$shop.$itemColour.$st);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&st=".$st."&shop=".$shop."&id=".$id."&itemColour=".$itemColour);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
		#hash=c30e3880dfd95893b5dc3e3dc9649155&st=586031&locID=999999&total=1000&idx=213265581
		#$locid.$idx.$total.$st);
	}

#loop 1 item
#for ($i = 0; $i < 100; $i++) { #if u put 100 it will give 3585 xp per request.
#    itemgiver(3074);
#    var_dump($outputnigga);
#}

foreach (range(801,900) as $id) {
    itemhack($id);
}



?>
</div>
</div>
<?php
include_once('footer.php');
?>