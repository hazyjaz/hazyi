<?php include_once('header.php'); ?>
<div class="container">
<div class="content">
<h2>404 - File not found</h2>
You reached this page in error.
</div>
</div>
<?php include_once('footer.php'); ?>