<?php
$title = "Weevil lookup - BWI";
include_once('header.php');
?>
<div class="container">
<div class="content">
<h1>amount</h1>
<?php
	include_once('utils.php');#
	makevalidsession();
	checkmulchandexp();

	var_dump($OUTPUTYOUBLACKNIGER);
?>
<h1>item giver 0day</h1>
<br />
<?php

		function saveitem2($progress) {##game stuff
		$curl = curl_init("http://lb.binweevils.com/php/saveWordSearchProgress.php?rndVar=0.5179709065705538");
		curl_setopt($curl, CURLOPT_POST, true);
		$completed = 1;
		$userID = "coldace"; //suprisingly works lol just change gridid and stuff
		$gridID = 23;
		curl_setopt($curl, CURLOPT_POSTFIELDS, "completed=".$completed."&userID=".$userID."&progress=".$progress."&gridID=".$gridID);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print 'received:'.$outputnigga; // works but limited with grids :/
		print '<h2>The mulch given was='.$progress.' !</h2>'; #
		print $outputnigga;
		}

 foreach (range(1, 60) as $progress) {
    saveitem2($progress);
 }


?>
</div>
</div>
<?php
include_once('footer.php');
?>