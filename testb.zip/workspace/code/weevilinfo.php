<?php
$title = "Weevil lookup - BWI";
include_once('header.php');
?>
<div class="container">
<div class="content">
<?php
	include_once('utils.php');
	if (!empty($_POST['weevil'])) {
		makevalidsession();
		$weevildata = getweevilinfo($_POST['weevil']);

		echo "<h3>Weevil lookup result</h3>";
		if ($weevildata['weevil'] == null) {
			echo "Weevil '".$_POST['weevil']. "' doesn't exist or something went wrong (like they added more protection, lol!)."; 
		} else { 
			// no point in echoing the last login - it's wrong.
			//$d = new DateTime($weevildata['weevils']['lastLog']);
			//$df = $d->format('l, d-M-y H:i:s T');
			echo 
			"Idx: ".$weevildata['weevil']['idx'].
			"<br />"."Username: ".$_POST['weevil'].
			"<br />"."Level: ".$weevildata['weevil']['level'].
			//"<br />"."Last login: ".$df."<br />".
			"<br />"."Join date: ".$weevildata['weevil']['dateJoined'].
			"<br />"."Tycoon membership: "; if ($weevildata['weevil']['tycoon']) { echo 'yes'; } else { echo 'no'; }
			if ($weevildata['weevil']['petIds'] == null) { echo '<br />Pet: no'; } else { echo '<br /><form id="petclick" method="post" type="hidden" action="/petinfo"><input type="hidden" name="PetID" value="'.$weevildata["weevil"]["petIds"].'" />Pet: <font color="blue"><u><a onclick="document.getElementById(\'petclick\').submit();">'.$weevildata["weevil"]["petIds"].'</a></u></font></form>'; }
		}
		//debug stuff
		echo "<br />===============- Debug stuff -===============<br /><br />Weevil data dump: <pre>";
		echo var_dump($weevildata);
		echo "</pre>";
		echo "<br />Login data dump: <pre>";
		echo var_dump($loginresponse);
		echo "</pre>";
	} else {
		echo
		"<h3>Weevil lookup</h3>
		Type in a weevil username and press search to see its information.<br />";
	}
?>
<br />
<form action='' method='post'>
    <input type='text' name='weevil' />
    <input type='submit' value='Search' />
</form>
</div>
</div>
<?php
include_once('footer.php');
?>