<?php
$title = "Weevil lookup - BWI";
include_once('header.php');
?>
<div class="container">
<div class="content">
<h1>amount</h1>
<?php
	include_once('utils.php');#
	makevalidsession();
	checkmulchandexp();

	var_dump($OUTPUTYOUBLACKNIGER);
?>
<h1>mulch 0day</h1>
<br />
<?php


startPlayingVideo();



?>
</div>
</div>
<?php
include_once('footer.php');
?>