<?php
$title = "Weevil lookup - BWI";
include_once('header.php');
?>
<div class="container">
<div class="content">
<h1>amount</h1>
<?php
	include_once('utils.php');#
	makevalidsession();
	checkmulchandexp();

	var_dump($OUTPUTYOUBLACKNIGER);
?>
<h1>item giver 0day</h1>
<br />
<?php

for ($i = 0; $i < 500; $i++) {
    trialmulch();
    var_dump($outputnigga);
}


?>
</div>
</div>
<?php
include_once('footer.php');
?>