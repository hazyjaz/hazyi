<?php
$title = "Weevil lookup - BWI";
include_once('header.php');
?>
<div class="container">
<div class="content">
<h1>amount</h1>
<?php
	include_once('utils.php');#
	makevalidsession();
	checkmulchandexp();

	var_dump($OUTPUTYOUBLACKNIGER);
?>
<h1>mulch 0day</h1>
<br />
<?php


hashgeneratorforapis(); // you get this and swap the hash= 
// for this link http://lb.binweevils.com/php2/photobooth/upload-framed-picture.php?rndVar=0.6125882100313902&color=0&itemTypeID=202&picHash=d214da69c497a964f9fa6107c1e65d2c&timer=448747&hash=9dd03437568422f6e6eecd31ddadd65b
// change timer too.


?>
</div>
</div>
<?php
include_once('footer.php');
?>