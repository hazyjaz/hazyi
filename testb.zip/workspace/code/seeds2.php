<?php
$title = "Weevil lookup - BWI";
include_once('header.php');
?>
<div class="container">
<div class="content">
<h1>amount</h1>
<?php
	include_once('utils.php');#
	makevalidsession();
	checkmulchandexp();

	var_dump($OUTPUTYOUBLACKNIGER);
?>
<h1>item giver 0day</h1>
<br />
<?php

	function freeseeds1($seedList) {
		$curl = curl_init("http://lb.binweevils.com/rewards/collect-seeds");
		curl_setopt($curl, CURLOPT_POST, true);
		$st = timer_getandinc();
		$idx = file_get_contents("idx.txt");
		$hash = o2_genhash($idx.$seedList.$st);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "idx=".$idx."&st=".$st."&seedList=".$seedList."&hash=".$hash);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;
}

foreach (range(1, 210) as $freeseeds) {
	freeseeds1($freeseeds);
 }


?>
</div>
</div>
<?php
include_once('footer.php');
?>