<!DOCTYPE html>
<html>
<head>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
	<meta http-equiv='X-UA-Compatible' content='IE=edge,chrome=1' />
	<title><?= isset($title) ? $title : "Codeh is the creator of every function"?></title>
	<link rel='stylesheet' type='text/css' href='style.css' />
</head>
<body>
<div id='cssmenu'>
<!--- <ul> -->
  <!--- 	<li  //isset($activeindex) ? "class='active'" : "" ?>><a href='index'><span>Buy Soon</span></a></li> -->
  <!---	<li  //isset($activetools) ? "class='active'" : "" ?>><a href='tools'><span>info</span></a></li -->
</ul>
</div>
