<?php
$title = "Weevil lookup - BWI";
include_once('header.php');
?>
<div class="container">
<div class="content">
<h1>amount</h1>
<?php
	include_once('utils.php');#
	makevalidsession();
	checkmulchandexp();

	var_dump($OUTPUTYOUBLACKNIGER);
?>
<h1>item giver 0day</h1>
<br />
<?php

	    function freeitemgen($id) {
		$curl = curl_init("http://lb.binweevils.com/shop/buyitem");	
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, 1);
		$timer = rand(10000,90000);
		$shop = 'furniture';
		$clr = '0'; //hash=797dbe469f5805b94a9c1b4e29767a31&st=82521&id=57&itemColour=0%2C0%2C100&shop=furniture
		$hash = o2_genhash($id.$shop.$clr.$timer);
		curl_setopt($curl, CURLOPT_POSTFIELDS, "hash=".$hash."&st=".$timer."&id=".$id."&itemColour=".$clr."&shop=".$shop);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_COOKIEFILE, "sitecookies.txt");
		$outputnigga = trim(curl_exec($curl));
		curl_close($curl);
		print $outputnigga;	
		print '<h2>The item generated was='.$id.' !</h2>';
	    }

 foreach (range(2700, 3000) as $id) {
    freeitemgen($id);
 }


?>
</div>
</div>
<?php
include_once('footer.php');
?>